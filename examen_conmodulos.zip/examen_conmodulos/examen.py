# Llamada a la función para añadir o actualizar usuarios

from examen_conmodulos.modulos.genera_usuario import anadir_actulizar_usuario

anadir_actulizar_usuario()
