# Función para generar el campo (login)
def generate_login(name, last_name1):
    login = name.lower()[0] + last_name1.lower()
    return login
